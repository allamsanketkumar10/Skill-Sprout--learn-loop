
// ==================================================
// SKILLSPROUT: LEARNLOOP
// COMPLETE APPLICATION JAVASCRIPT
// ==================================================

// ==================================================
// 1. COURSE DATABASE - 40 ENGINEERING COURSES
// ==================================================

const courses = [
    {code:"ENG101",title:"Communication Skills",credits:2,difficulty:"Beginner",prerequisites:[],category:"General"},
    {code:"MTH101",title:"Engineering Mathematics I",credits:4,difficulty:"Beginner",prerequisites:[],category:"Core"},
    {code:"PHY101",title:"Engineering Physics",credits:3,difficulty:"Beginner",prerequisites:[],category:"Core"},
    {code:"CHM101",title:"Engineering Chemistry",credits:3,difficulty:"Beginner",prerequisites:[],category:"Core"},
    {code:"CS101",title:"Introduction to Programming",credits:3,difficulty:"Beginner",prerequisites:[],category:"Programming"},
    {code:"ECE101",title:"Basic Electronics",credits:3,difficulty:"Beginner",prerequisites:[],category:"Electronics"},
    {code:"ME101",title:"Engineering Mechanics",credits:3,difficulty:"Beginner",prerequisites:[],category:"Mechanical"},
    {code:"IT101",title:"Computer Fundamentals",credits:2,difficulty:"Beginner",prerequisites:[],category:"Programming"},
    {code:"MTH102",title:"Engineering Mathematics II",credits:4,difficulty:"Intermediate",prerequisites:["MTH101"],category:"Core"},
    {code:"CS102",title:"Data Structures",credits:4,difficulty:"Intermediate",prerequisites:["CS101"],category:"Programming"},
    {code:"CS103",title:"Object Oriented Programming",credits:3,difficulty:"Intermediate",prerequisites:["CS101"],category:"Programming"},
    {code:"ECE102",title:"Digital Electronics",credits:3,difficulty:"Intermediate",prerequisites:["ECE101"],category:"Electronics"},
    {code:"CS104",title:"Database Management Systems",credits:3,difficulty:"Intermediate",prerequisites:["CS101"],category:"Programming"},
    {code:"CS105",title:"Web Development Fundamentals",credits:3,difficulty:"Beginner",prerequisites:["CS101"],category:"Web"},
    {code:"PHY102",title:"Applied Physics",credits:3,difficulty:"Intermediate",prerequisites:["PHY101"],category:"Core"},
    {code:"CS201",title:"Algorithms",credits:4,difficulty:"Advanced",prerequisites:["CS102"],category:"Programming"},
    {code:"CS202",title:"Operating Systems",credits:3,difficulty:"Advanced",prerequisites:["CS102"],category:"Programming"},
    {code:"CS203",title:"Computer Networks",credits:3,difficulty:"Intermediate",prerequisites:["CS101"],category:"Programming"},
    {code:"CS204",title:"Advanced Web Development",credits:4,difficulty:"Advanced",prerequisites:["CS105","CS104"],category:"Web"},
    {code:"CS205",title:"Python Programming",credits:3,difficulty:"Beginner",prerequisites:["CS101"],category:"Programming"},
    {code:"CS206",title:"Software Engineering",credits:3,difficulty:"Intermediate",prerequisites:["CS103"],category:"Programming"},
    {code:"ECE201",title:"Microprocessors",credits:4,difficulty:"Advanced",prerequisites:["ECE102"],category:"Electronics"},
    {code:"ECE202",title:"Analog Circuits",credits:3,difficulty:"Intermediate",prerequisites:["ECE101"],category:"Electronics"},
    {code:"ECE203",title:"Signals and Systems",credits:4,difficulty:"Advanced",prerequisites:["MTH102"],category:"Electronics"},
    {code:"CS207",title:"Machine Learning",credits:4,difficulty:"Advanced",prerequisites:["CS205","MTH102"],category:"AI"},
    {code:"CS208",title:"Data Analytics",credits:3,difficulty:"Intermediate",prerequisites:["CS205"],category:"AI"},
    {code:"CS209",title:"Cloud Computing",credits:3,difficulty:"Advanced",prerequisites:["CS203"],category:"Web"},
    {code:"CS210",title:"Cybersecurity Fundamentals",credits:3,difficulty:"Intermediate",prerequisites:["CS203"],category:"Security"},
    {code:"CS301",title:"Artificial Intelligence",credits:4,difficulty:"Advanced",prerequisites:["CS207"],category:"AI"},
    {code:"CS302",title:"Deep Learning",credits:4,difficulty:"Advanced",prerequisites:["CS207"],category:"AI"},
    {code:"CS303",title:"Full Stack Development",credits:4,difficulty:"Advanced",prerequisites:["CS204"],category:"Web"},
    {code:"CS304",title:"Ethical Hacking",credits:3,difficulty:"Advanced",prerequisites:["CS210"],category:"Security"},
    {code:"ECE301",title:"Embedded Systems",credits:4,difficulty:"Advanced",prerequisites:["ECE201","ECE102"],category:"Electronics"},
    {code:"ECE302",title:"VLSI Design",credits:4,difficulty:"Advanced",prerequisites:["ECE202","ECE203"],category:"Electronics"},
    {code:"ECE303",title:"Internet of Things",credits:3,difficulty:"Advanced",prerequisites:["ECE201"],category:"Electronics"},
    {code:"CS305",title:"Mobile Application Development",credits:3,difficulty:"Intermediate",prerequisites:["CS105"],category:"Web"},
    {code:"CS306",title:"DevOps Fundamentals",credits:3,difficulty:"Advanced",prerequisites:["CS209"],category:"Web"},
    {code:"CS307",title:"Big Data Technologies",credits:4,difficulty:"Advanced",prerequisites:["CS208"],category:"AI"},
    {code:"CS308",title:"Final Year Project",credits:4,difficulty:"Advanced",prerequisites:["CS206","CS201"],category:"Project"},
    {code:"ENG201",title:"Professional Ethics",credits:2,difficulty:"Beginner",prerequisites:[],category:"General"}
];

// ==================================================
// 2. APPLICATION STATE
// ==================================================

let student = null;
let enrolled = [];
let completed = [];
let roadmap = [];
let activeUser = null;

function storageKey(type) {
    return "skill_" + type + "_" + activeUser.email;
}

function saveData() {
    if (!activeUser) return;

    localStorage.setItem(storageKey("student"), JSON.stringify(student));
    localStorage.setItem(storageKey("enrolled"), JSON.stringify(enrolled));
    localStorage.setItem(storageKey("completed"), JSON.stringify(completed));
}

function loadData() {
    student = JSON.parse(localStorage.getItem(storageKey("student"))) || null;
    enrolled = JSON.parse(localStorage.getItem(storageKey("enrolled"))) || [];
    completed = JSON.parse(localStorage.getItem(storageKey("completed"))) || [];
}

// ==================================================
// 3. AUTHENTICATION - LOGIN AND SIGNUP
// ==================================================

const authPage = document.getElementById("authPage");
const appPage = document.getElementById("appPage");

const loginForm = document.getElementById("loginForm");
const signupForm = document.getElementById("signupForm");

const loginTab = document.getElementById("loginTab");
const signupTab = document.getElementById("signupTab");

const authMessage = document.getElementById("authMessage");

function getUsers() {
    return JSON.parse(localStorage.getItem("skillUsers")) || [];
}

function saveUsers(users) {
    localStorage.setItem("skillUsers", JSON.stringify(users));
}

function showAuthMessage(message, type) {
    authMessage.textContent = message;
    authMessage.className = "auth-message " + type;
}

function showLogin() {
    loginForm.classList.remove("hidden");
    signupForm.classList.add("hidden");

    loginTab.classList.add("active");
    signupTab.classList.remove("active");

    showAuthMessage("", "");
}

function showSignup() {
    signupForm.classList.remove("hidden");
    loginForm.classList.add("hidden");

    signupTab.classList.add("active");
    loginTab.classList.remove("active");

    showAuthMessage("", "");
}

loginTab.addEventListener("click", showLogin);
signupTab.addEventListener("click", showSignup);

document.getElementById("showSignup").addEventListener("click", event => {
    event.preventDefault();
    showSignup();
});

document.getElementById("showLogin").addEventListener("click", event => {
    event.preventDefault();
    showLogin();
});

// REGISTER NEW STUDENT

signupForm.addEventListener("submit", event => {
    event.preventDefault();

    const name = document.getElementById("signupName").value.trim();
    const email = document.getElementById("signupEmail").value.trim().toLowerCase();
    const password = document.getElementById("signupPassword").value;
    const confirm = document.getElementById("confirmPassword").value;

    if (name.length < 2) {
        showAuthMessage("Please enter a valid name.", "error");
        return;
    }

    if (password.length < 6) {
        showAuthMessage("Password must contain at least 6 characters.", "error");
        return;
    }

    if (password !== confirm) {
        showAuthMessage("Passwords do not match!", "error");
        return;
    }

    const users = getUsers();

    if (users.some(user => user.email === email)) {
        showAuthMessage("Email already registered. Please login.", "error");
        return;
    }

    users.push({
        name,
        email,
        password
    });

    saveUsers(users);

    signupForm.reset();

    showAuthMessage("Account created successfully! Please login.", "success");

    setTimeout(() => {
        showLogin();
        document.getElementById("loginEmail").value = email;
    }, 1000);
});

// LOGIN STUDENT

loginForm.addEventListener("submit", event => {
    event.preventDefault();

    const email = document.getElementById("loginEmail").value.trim().toLowerCase();
    const password = document.getElementById("loginPassword").value;

    const user = getUsers().find(account =>
        account.email === email && account.password === password
    );

    if (!user) {
        showAuthMessage("Invalid email or password. Try again.", "error");
        return;
    }

    const session = {
        name: user.name,
        email: user.email
    };

    localStorage.setItem("skillSession", JSON.stringify(session));

    loginForm.reset();
    openDashboard(session);
});

// ==================================================
// 4. OPEN DASHBOARD
// ==================================================

function openDashboard(user) {
    activeUser = user;

    loadData();

    authPage.classList.add("hidden");
    appPage.classList.remove("hidden");

    document.getElementById("profileName").textContent = user.name;

    if (!student) {
        student = {
            name: user.name,
            branch: "",
            semester: "1",
            coding: "beginner",
            career: ""
        };
    } else {
        student.name = user.name;
    }

    document.getElementById("studentName").value = user.name;

    document.getElementById("branch").value = student.branch || "";
    document.getElementById("semester").value = student.semester || "1";
    document.getElementById("coding").value = student.coding || "beginner";
    document.getElementById("career").value = student.career || "";

    saveData();

    if (student.branch && student.career) {
        generateRoadmap();
    } else {
        roadmap = [];
        renderCourses();
        renderRoadmap();
        updateDashboard();
    }

    document.getElementById("welcomeMessage").textContent =
        "Welcome back, " + user.name + "! Start growing your skills.";
}

// ==================================================
// 5. LOGOUT
// ==================================================

document.getElementById("logoutBtn").addEventListener("click", () => {
    if (!confirm("Are you sure you want to logout?")) return;

    localStorage.removeItem("skillSession");

    activeUser = null;
    student = null;
    enrolled = [];
    completed = [];
    roadmap = [];

    appPage.classList.add("hidden");
    authPage.classList.remove("hidden");

    showLogin();
});

// ==================================================
// 6. DAG TOPOLOGICAL SORT - KAHN'S ALGORITHM
// ==================================================

function topologicalSort() {
    const indegree = {};
    const graph = {};

    courses.forEach(course => {
        indegree[course.code] = 0;
        graph[course.code] = [];
    });

    courses.forEach(course => {
        course.prerequisites.forEach(pre => {
            if (!Object.prototype.hasOwnProperty.call(indegree, pre)) {
                throw new Error("Missing prerequisite: " + pre);
            }

            graph[pre].push(course.code);
            indegree[course.code]++;
        });
    });

    const queue = Object.keys(indegree).filter(
        code => indegree[code] === 0
    );

    const sorted = [];

    while (queue.length > 0) {
        const current = queue.shift();

        sorted.push(current);

        graph[current].forEach(next => {
            indegree[next]--;

            if (indegree[next] === 0) {
                queue.push(next);
            }
        });
    }

    if (sorted.length !== courses.length) {
        throw new Error("Circular prerequisite dependency detected!");
    }

    return sorted;
}

// ==================================================
// 7. GENERATE PERSONALIZED ROADMAP
// ==================================================

function generateRoadmap() {
    try {
        const sorted = topologicalSort();
        const levels = {};

        sorted.forEach(code => {
            const course = courses.find(c => c.code === code);

            const prerequisiteLevel = course.prerequisites.length
                ? Math.max(...course.prerequisites.map(p => levels[p]))
                : 0;

            levels[code] = prerequisiteLevel + 1;
        });

        const priority = {
            "Full-Stack Web Development": ["Web","Programming","General","Core"],
            "Artificial Intelligence": ["AI","Programming","Core","General"],
            "Data Science": ["AI","Programming","Core","General"],
            "Embedded Systems": ["Electronics","Core","Programming","General"],
            "VLSI Design": ["Electronics","Core","Programming","General"],
            "Cybersecurity": ["Security","Programming","Web","Core","General"],
            "Robotics": ["Electronics","Programming","Core","General"]
        };

        const preferred = priority[student.career] || [];

        roadmap = sorted.map(code => {
            const course = courses.find(c => c.code === code);
            const semester = levels[code];

            return {
                ...course,
                semester,
                priority: preferred.indexOf(course.category) === -1
                    ? 99
                    : preferred.indexOf(course.category)
            };
        });

        // Career preference only reorders courses within the same
        // prerequisite level, so dependency ordering remains valid.
        roadmap.sort((a, b) =>
            a.semester - b.semester || a.priority - b.priority
        );

        renderRoadmap();
        renderCourses();
        updateDashboard();

        document.getElementById("roadmapSubtitle").textContent =
            "Your " + student.career + " learning roadmap is ready!";

    } catch (error) {
        alert(error.message);
    }
}

// ==================================================
// 8. PREREQUISITE VALIDATION
// ==================================================

function isUnlocked(course) {
    return course.prerequisites.every(pre =>
        completed.includes(pre)
    );
}

function getStatus(course) {
    if (completed.includes(course.code)) return "completed";
    if (enrolled.includes(course.code)) return "enrolled";
    if (isUnlocked(course)) return "available";

    return "locked";
}

// ==================================================
// 9. COURSE ENROLLMENT
// ==================================================

function enrollCourse(code) {
    const course = courses.find(c => c.code === code);

    if (!course) return;

    if (!isUnlocked(course)) {
        const missing = course.prerequisites.filter(
            pre => !completed.includes(pre)
        );

        alert("Complete these prerequisites first: " + missing.join(", "));
        return;
    }

    if (enrolled.includes(code) || completed.includes(code)) return;

    enrolled.push(code);

    saveData();
    renderCourses();
    renderRoadmap();
    updateDashboard();

    alert("Successfully enrolled in " + course.title + "!");
}

// ==================================================
// 10. COMPLETE COURSE
// ==================================================

function completeCourse(code) {
    const course = courses.find(c => c.code === code);

    if (!course || !enrolled.includes(code)) return;

    if (!isUnlocked(course)) {
        alert("Prerequisites are not completed yet.");
        return;
    }

    enrolled = enrolled.filter(c => c !== code);
    completed.push(code);

    saveData();

    renderCourses();
    renderRoadmap();
    updateDashboard();

    alert(course.code + " marked as completed!");
}

// ==================================================
// 11. RENDER COURSE CATALOG
// ==================================================

function renderCourses() {
    const search = document.getElementById("searchInput")
        .value.toLowerCase().trim();

    const difficulty = document.getElementById("difficultyFilter").value;
    const credits = document.getElementById("creditFilter").value;

    const filtered = courses.filter(course => {
        const matchesSearch =
            course.code.toLowerCase().includes(search) ||
            course.title.toLowerCase().includes(search);

        const matchesDifficulty =
            !difficulty || course.difficulty === difficulty;

        const matchesCredits =
            !credits || String(course.credits) === credits;

        return matchesSearch && matchesDifficulty && matchesCredits;
    });

    const container = document.getElementById("courseList");

    if (!filtered.length) {
        container.innerHTML =
            "<div class='empty-state'>No matching courses found.</div>";
        return;
    }

    container.innerHTML = filtered.map(course => {
        const status = getStatus(course);

        let buttonText = "Enroll Now";
        let disabled = false;
        let action = "enroll";
        
        if (status === "completed") {
            buttonText = "✓ Completed";
            disabled = true;
        } else if (status === "enrolled") {
            buttonText = "Mark Completed";
            action = "complete";
        } else if (status === "locked") {
            buttonText = "🔒 Prerequisites Pending";
            disabled = true;
        }

        return `
            <div class="course-card">
                <span class="course-code">${course.code}</span>
                <h3>${course.title}</h3>

                <p>Prerequisites:
                    ${course.prerequisites.length
                        ? course.prerequisites.join(", ")
                        : "None"}
                </p>

                <div class="course-tags">
                    <span>${course.credits} Credits</span>
                    <span>${course.difficulty}</span>
                    <span>${course.category}</span>
                </div>

                <button
                    data-action="${action}"
                    data-code="${course.code}"
                    ${disabled ? "disabled" : ""}>
                    ${buttonText}
                </button>
            </div>
        `;
    }).join("");
}

// Course buttons use event delegation
document.getElementById("courseList").addEventListener("click", event => {
    const button = event.target.closest("button[data-action]");

    if (!button || button.disabled) return;

    const code = button.dataset.code;

    if (button.dataset.action === "enroll") {
        enrollCourse(code);
    } else if (button.dataset.action === "complete") {
        completeCourse(code);
    }
});

// ==================================================
// 12. RENDER ROADMAP
// ==================================================

function renderRoadmap() {
    const container = document.getElementById("roadmapContainer");

    if (!student || !student.career) {
        container.innerHTML = `
            <div class="empty-state">
                🌱 Complete your diagnostic form to generate your roadmap.
            </div>
        `;
        return;
    }

    let html = "";

    // Show the four next roadmap semesters
    for (let semester = 1; semester <= 4; semester++) {
        const semesterCourses = roadmap.filter(
            course => course.semester === semester
        );

        if (!semesterCourses.length) continue;

        const semesterCredits = semesterCourses.reduce(
            (sum, course) => sum + course.credits, 0
        );

        html += `
            <div class="semester-card">
                <div class="semester-title">
                    <h3>📘 Semester ${semester}</h3>
                    <span>${semesterCredits} Credits</span>
                </div>
        `;

        semesterCourses.forEach(course => {
            const status = getStatus(course);

            let label = "Available";

            if (status === "completed") label = "✓ Completed";
            if (status === "enrolled") label = "Enrolled";
            if (status === "locked") label = "🔒 Locked";

            html += `
                <div class="roadmap-course">
                    <h4>${course.code} - ${course.title}</h4>

                    <p>
                        ${course.credits} Credits · ${course.difficulty}
                    </p>

                    <span class="status ${status}">${label}</span>

                    ${status === "available" ? `
                        <button class="roadmap-action"
                            data-action="enroll"
                            data-code="${course.code}">
                            Enroll
                        </button>
                    ` : ""}

                    ${status === "enrolled" ? `
                        <button class="roadmap-action"
                            data-action="complete"
                            data-code="${course.code}">
                            Mark Complete
                        </button>
                    ` : ""}
                </div>
            `;
        });

        html += "</div>";
    }

    container.innerHTML = html;
}

// Roadmap buttons
document.getElementById("roadmapContainer").addEventListener("click", event => {
    const button = event.target.closest("button[data-action]");

    if (!button) return;

    const code = button.dataset.code;

    if (button.dataset.action === "enroll") {
        enrollCourse(code);
    } else if (button.dataset.action === "complete") {
        completeCourse(code);
    }
});

// ==================================================
// 13. DASHBOARD AND PROGRESS TRACKER
// ==================================================

function updateDashboard() {
    const earnedCredits = courses
        .filter(c => completed.includes(c.code))
        .reduce((sum, c) => sum + c.credits, 0);

    const enrolledCredits = courses
        .filter(c => enrolled.includes(c.code))
        .reduce((sum, c) => sum + c.credits, 0);

    const totalStudyHours = courses
        .filter(c => enrolled.includes(c.code))
        .reduce((sum, c) => {
            const hours = {
                Beginner: 2,
                Intermediate: 3,
                Advanced: 5
            };

            return sum + hours[c.difficulty];
        }, 0);

    // Four milestone units: each completed unit represents 25%.
    // Once all four are completed, progress reaches 100%.
    const percentage = Math.min(
        100,
        Math.round((completed.length / 4) * 100)
    );

    document.getElementById("enrolledCount").textContent = enrolled.length;
    document.getElementById("completedCount").textContent = completed.length;
    document.getElementById("creditsEarned").textContent = earnedCredits;
    document.getElementById("studyHours").textContent = totalStudyHours;

    document.getElementById("progressPercent").textContent =
        percentage + "%";

    document.getElementById("progressCircle").style.background =
        `conic-gradient(var(--primary) ${percentage * 3.6}deg, #e9efeb 0deg)`;

    document.getElementById("progressBar").style.width =
        percentage + "%";

    document.getElementById("progressDescription").textContent =
        completed.length + " completed courses. " +
        enrolled.length + " courses currently enrolled.";

    document.getElementById("creditProgress").textContent =
        earnedCredits + " credits earned · " +
        enrolledCredits + " credits currently enrolled";

    document.getElementById("studyEstimate").textContent =
        totalStudyHours + " hours/week";

    if (student) {
        document.getElementById("welcomeMessage").textContent =
            "Welcome, " + student.name + "! Your goal: " +
            (student.career || "Choose your career pathway");
    }
}

// ==================================================
// 14. STUDENT DIAGNOSTIC FORM
// ==================================================

document.getElementById("diagnosticForm").addEventListener("submit", event => {
    event.preventDefault();

    if (!activeUser) return;

    student = {
        name: activeUser.name,
        branch: document.getElementById("branch").value,
        semester: document.getElementById("semester").value,
        coding: document.getElementById("coding").value,
        career: document.getElementById("career").value
    };

    if (!student.branch || !student.career) {
        alert("Please complete all diagnostic fields.");
        return;
    }

    saveData();

    generateRoadmap();

    alert("Your personalized learning roadmap has been generated!");

    document.getElementById("roadmap").scrollIntoView({
        behavior: "smooth"
    });
});

// ==================================================
// 15. SEARCH AND FILTER
// ==================================================

document.getElementById("searchInput")
    .addEventListener("input", renderCourses);

document.getElementById("difficultyFilter")
    .addEventListener("change", renderCourses);

document.getElementById("creditFilter")
    .addEventListener("change", renderCourses);

// ==================================================
// 16. EXPORT ROADMAP AS PDF
// ==================================================

document.getElementById("exportBtn").addEventListener("click", () => {
    if (!student || !student.career) {
        alert("Please generate your roadmap first!");
        return;
    }

    window.print();
});

// ==================================================
// 17. INITIALIZE APPLICATION
// ==================================================

function initializeApp() {
    renderCourses();

    const session = JSON.parse(
        localStorage.getItem("skillSession") || "null"
    );

    if (session && session.email) {
        const userExists = getUsers().some(
            user => user.email === session.email
        );

        if (userExists) {
            openDashboard(session);
            return;
        }

        localStorage.removeItem("skillSession");
    }

    authPage.classList.remove("hidden");
    appPage.classList.add("hidden");

    showLogin();
}

initializeApp();

// ==================================================
// END OF SKILLSPROUT APPLICATION
// ==================================================
